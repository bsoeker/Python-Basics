from zipfile import ZipFile
from pathlib import Path


zip_file = ZipFile("./files.zip", "w")
for path in Path("./").iterdir():
    zip_file.write(path)
